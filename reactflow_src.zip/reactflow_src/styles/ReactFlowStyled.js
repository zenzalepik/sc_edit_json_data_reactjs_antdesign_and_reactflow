//ReactFlowStyled.js

import {
  ReactFlow,
  // useNodesState,
  // useEdgesState,
  // addEdge,
  // MiniMap,
  // Controls,
  // Panel,
  // Background,
} from "@xyflow/react";
import styled
//, { ThemeProvider } 
from "styled-components";

const ReactFlowStyled = styled(ReactFlow)``;

export default ReactFlowStyled;
