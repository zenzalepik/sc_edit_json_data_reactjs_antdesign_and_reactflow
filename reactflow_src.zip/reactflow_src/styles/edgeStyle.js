// edgeStyle.js

const edgeStyle = {
    stroke: "#aaa", // Warna garis sambung
    strokeWidth: 2, // Ketebalan garis sambung
    strokeLinecap: "round", // Ujung garis sambung yang lebih halus
  };
  
  export default edgeStyle;
  